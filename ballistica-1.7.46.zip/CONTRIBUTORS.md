# Ballistica Contributors
(please add your name and info here if you have contributed to the project)

### Eric Froemling
- Original BombSquad/Ballistica author and BDFL (benevolent dictator for life).

### Dmitry450
- Modder
- Fixed some game modes

### Dliwk
- Bug fixes and a few features.

### Benefit-Zebra
- Unofficial BombSquad Bug Finder
- Code Cleanup

### Ali Borhani
- Bug fixes

### Mr.Smoothy
- Modder

### Daniil Rakhov
- Plugin api additions

### Ritiek Malhotra
- Just <3 BombSquad

### Ivan Ms
- Few camera features

### Droopy
- Fixes in some minigames

### Easy10781
- Added feature

### Vishal332008
- QoL and Bug Fixer
- Modder

### Era0S
- Community Suggestions Implementer
- QoL and Bug Fixer
- Modder

### VinniTR
- Fixes

### Rikko
- Created the original "reject_recently_left_players" plugin

### SoK
- Modder
- BSE Heartbeat mechanic port

### Temp (3alTemp)
- Original idea for customizable series length on GUI builds
- Modder & Bug Fixer

### brostos
- Added support for joining using ipv6 address

### Loup Garou
- Added sphinx documentation generation
- Added docker build system
- Various CI/CD improvements
- Added discord social sdk support

### komasio71
- Retired Discord server moderator
- Small contributor
