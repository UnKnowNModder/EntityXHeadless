# Ballistica Assets

This directory contains sources used to build bundled scripts, models,
textures, etc.
