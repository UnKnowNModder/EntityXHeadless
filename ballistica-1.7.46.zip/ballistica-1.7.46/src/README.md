# Ballistica Source

(Mostly) everything contributing to Ballistica builds lives here.

### Noteworthy Bits:

- [assets/ba_data/python](assets/ba_data/python): Where most Python code going
  in to the app lives.
- [ballistica](ballistica): Where the native (C++, etc.) layer of the app lives.
- [meta](meta): Code used to generate other code (metaprogramming).
