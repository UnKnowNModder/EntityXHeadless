# Ballistica Tool Config Source

These configs can be installed via 'make env' in the project root.
(this should automatically happen as part of other targets such as 'make check')

Some of these are filtered to include an abs path to the project root or other
dynamically generated data, which is why we use this mechanism instead of simply
including them as flat files.
