# Released under the MIT License. See LICENSE for details.
#
"""Snippets of code for use by the native layer."""

from __future__ import annotations


def hello_world() -> None:
    """The usual example."""
    print('HELLO WORLD FROM TemplateFs!')
